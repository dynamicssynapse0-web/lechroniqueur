import { redirect, notFound } from 'next/navigation';
import EditerProfil from '../../../components/EditerProfil';
import { exigerAuteurActif } from '../../../lib/auteur';
import { lienJournaliste } from '../../../lib/journalistes';
import './profil.css';

export const metadata = {
  title: 'Mon profil',
  robots: { index: false, follow: false },
};

export default async function MonProfil() {
  const { supabase, utilisateurId } = await exigerAuteurActif();

  const { data: profil } = await supabase
    .from('profiles')
    .select('prenom, nom, media, email, ville, pays, role')
    .eq('id', utilisateurId)
    .maybeSingle();

  if (!profil) notFound();
  if (profil.role === 'admin') redirect('/admin');

  const { data: fiche } = await supabase
    .from('journalistes')
    .select('bio')
    .eq('id', utilisateurId)
    .maybeSingle();

  const lienPublic = lienJournaliste({
    id: utilisateurId,
    prenom: profil.prenom,
    nom: profil.nom,
  });

  return (
    <section>
      <h1>Mon profil</h1>
      <p className="intro-page">
        Votre biographie, votre ville et votre pays apparaissent sur votre profil
        public, dans l’annuaire et sous chacun de vos articles.
      </p>

      <EditerProfil
        identite={{
          prenom: profil.prenom,
          nom: profil.nom,
          media: profil.media,
          email: profil.email,
        }}
        initial={{
          bio: fiche?.bio ?? '',
          ville: profil.ville ?? '',
          pays: profil.pays ?? '',
        }}
        lienPublic={lienPublic}
      />
    </section>
  );
}
