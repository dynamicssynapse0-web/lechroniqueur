'use server';

import { revalidatePath } from 'next/cache';
import { creerClientServeur } from '../../../lib/supabase/serveur';

const texte = (v) => (typeof v === 'string' ? v.replace(/\r\n/g, '\n').trim() : '');

export async function enregistrerProfil(valeurs) {
  const bio = texte(valeurs?.bio);
  const ville = texte(valeurs?.ville);
  const pays = texte(valeurs?.pays);

  if (bio.length > 500) {
    return { erreur: 'La biographie ne doit pas dépasser 500 caractères.' };
  }
  if (ville.length < 2 || ville.length > 80) {
    return { erreur: 'Indiquez une ville valide.' };
  }
  if (pays.length < 2 || pays.length > 80) {
    return { erreur: 'Choisissez un pays valide.' };
  }

  const supabase = await creerClientServeur();
  const { data: session } = await supabase.auth.getClaims();
  if (!session?.claims?.sub) {
    return { erreur: 'Votre session a expiré. Reconnectez-vous.' };
  }

  const { error } = await supabase.rpc('modifier_mon_profil', {
    p_bio: bio,
    p_ville: ville,
    p_pays: pays,
  });
  if (error) {
    return { erreur: 'L’enregistrement a échoué. Réessayez dans un instant.' };
  }

  // Les pages publiques se mettent à jour tout de suite.
  revalidatePath('/journalistes');
  revalidatePath('/journalistes/[slug]', 'page');
  revalidatePath('/article/[slug]', 'page');

  return { ok: true };
}
