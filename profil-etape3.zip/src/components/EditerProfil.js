'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { PAYS } from '../lib/pays';
import { enregistrerProfil } from '../app/espace/profil/actions';

const BIO_MAX = 500;

function heure() {
  return new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

export default function EditerProfil({ identite, initial, lienPublic }) {
  const [valeurs, setValeurs] = useState(initial);
  const [erreurs, setErreurs] = useState({});
  const [enCours, setEnCours] = useState(false);
  const [modifie, setModifie] = useState(false);
  const [message, setMessage] = useState('');
  const [erreurServeur, setErreurServeur] = useState('');

  const paysConnus = PAYS.some((p) => p.nom === initial.pays);

  // Prévient avant de quitter la page avec des changements non enregistrés
  useEffect(() => {
    if (!modifie) return;
    const avertir = (e) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', avertir);
    return () => window.removeEventListener('beforeunload', avertir);
  }, [modifie]);

  function changer(e) {
    const { name, value } = e.target;
    setValeurs((v) => ({ ...v, [name]: value }));
    setModifie(true);
    setMessage('');
    setErreurServeur('');
    if (erreurs[name]) setErreurs((er) => ({ ...er, [name]: undefined }));
  }

  async function soumettre(evenement) {
    evenement.preventDefault();
    setMessage('');
    setErreurServeur('');

    const e = {};
    if (valeurs.ville.trim().length < 2) e.ville = 'Indiquez votre ville.';
    if (!valeurs.pays) e.pays = 'Choisissez votre pays.';
    if (valeurs.bio.length > BIO_MAX) e.bio = `La biographie ne doit pas dépasser ${BIO_MAX} caractères.`;
    setErreurs(e);

    const premier = Object.keys(e)[0];
    if (premier) {
      document.getElementById(premier)?.focus();
      return;
    }

    setEnCours(true);
    const resultat = await enregistrerProfil(valeurs);
    setEnCours(false);

    if (resultat?.erreur) {
      setErreurServeur(resultat.erreur);
      return;
    }

    setModifie(false);
    setMessage(`Profil enregistré à ${heure()}.`);
  }

  const restant = BIO_MAX - valeurs.bio.length;

  return (
    <div className="edition-profil">
      <section className="formulaire" aria-labelledby="titre-identite">
        <h2 id="titre-identite">Mon identité</h2>
        <dl className="infos-lecture">
          <div>
            <dt>Nom</dt>
            <dd>{`${identite.prenom} ${identite.nom}`.trim()}</dd>
          </div>
          <div>
            <dt>Média</dt>
            <dd>{identite.media}</dd>
          </div>
          <div>
            <dt>Adresse email (privée)</dt>
            <dd>{identite.email}</dd>
          </div>
        </dl>
        <p className="aide">
          Ces informations ont été vérifiées avec votre carte de presse et ne se
          modifient pas ici. Pour une correction, contactez l’équipe MediaPress.
        </p>
      </section>

      <section className="formulaire" aria-labelledby="titre-public">
        <h2 id="titre-public">Mon profil public</h2>

        <form onSubmit={soumettre} noValidate>
          <div className="grille-champs">
            <div className="champ">
              <label htmlFor="bio">Biographie</label>
              <textarea
                id="bio"
                name="bio"
                rows={7}
                maxLength={BIO_MAX}
                value={valeurs.bio}
                onChange={changer}
                aria-invalid={erreurs.bio ? 'true' : undefined}
                aria-describedby="bio-message"
              />
              {erreurs.bio ? (
                <p className="erreur" id="bio-message" role="alert">{erreurs.bio}</p>
              ) : (
                <p className="aide" id="bio-message">
                  Présentez-vous en quelques phrases : votre parcours, vos sujets de
                  prédilection. Évitez d’y mettre votre téléphone ou votre email : cette
                  page est publique.
                </p>
              )}
              <p className="compteur-champ">
                {restant} caractère{restant > 1 ? 's' : ''} restant{restant > 1 ? 's' : ''}
              </p>
            </div>

            <div className="champ">
              <label htmlFor="ville">Ville</label>
              <input
                id="ville"
                name="ville"
                type="text"
                autoComplete="address-level2"
                value={valeurs.ville}
                onChange={changer}
                aria-invalid={erreurs.ville ? 'true' : undefined}
                aria-describedby={erreurs.ville ? 'ville-message' : undefined}
              />
              {erreurs.ville && (
                <p className="erreur" id="ville-message" role="alert">{erreurs.ville}</p>
              )}
            </div>

            <div className="champ">
              <label htmlFor="pays">Pays</label>
              <select
                id="pays"
                name="pays"
                autoComplete="country-name"
                value={valeurs.pays}
                onChange={changer}
                aria-invalid={erreurs.pays ? 'true' : undefined}
                aria-describedby={erreurs.pays ? 'pays-message' : undefined}
              >
                <option value="">Choisissez votre pays</option>
                {!paysConnus && initial.pays && (
                  <option value={initial.pays}>{initial.pays}</option>
                )}
                {PAYS.map((p) => (
                  <option key={p.nom} value={p.nom}>{p.nom}</option>
                ))}
              </select>
              {erreurs.pays && (
                <p className="erreur" id="pays-message" role="alert">{erreurs.pays}</p>
              )}
            </div>

            <div aria-live="polite">
              {erreurServeur && <p className="erreur" role="alert">{erreurServeur}</p>}
              {message && (
                <p className="info" role="status">
                  {message} <Link href={lienPublic}>Voir mon profil public</Link>
                </p>
              )}
            </div>

            <div className="actions-profil">
              <button type="submit" className="btn-principal" disabled={enCours}>
                {enCours ? 'Enregistrement…' : 'Enregistrer'}
              </button>
              <Link href="/espace">Retour à mes articles</Link>
            </div>
          </div>
        </form>
      </section>
    </div>
  );
}
